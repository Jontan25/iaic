/*
 * Created on Sep 14, 2003 by Ravi Mohan
 *
 */
package aima.logic.fol.parsing.ast;

public abstract class Term implements FOLNode {

	public abstract Term copy();
}
