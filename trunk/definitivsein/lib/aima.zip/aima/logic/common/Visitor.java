/*
 * Created on Sep 15, 2003 by Ravi Mohan
 *  
 */
package aima.logic.common;

/**
 * @author Ravi Mohan
 * 
 */

public interface Visitor {

}