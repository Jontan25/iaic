package aima.basic;

public class MockAgent extends Agent {

	/**
	 * @author Ravi Mohan
	 * 
	 */
}